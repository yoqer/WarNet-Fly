# 🔐 Guía de Acceso al Panel Oculto - WarNet Command V4

**⚠️ DOCUMENTO CONFIDENCIAL**  
**Solo disponible en:** WarNet-Command-V4-Final-Production.zip  
**Fecha:** 26 de Mayo de 2026

---

## 📌 Información Importante

Este documento contiene instrucciones **exclusivas** para acceder al panel de control oculto del sistema WarNet Command V4. Esta información **NO** está disponible en la versión pública limpia (WarNet-Command-V4-Clean-Production.zip).

**El panel oculto solo existe en:**
- ✅ WarNet-Command-V4-Final-Production.zip
- ❌ WarNet-Command-V4-Clean-Production.zip
- ❌ Repositorio público GitHub

---

## 🔑 Acceso al Panel Oculto

### Combinación de Activación

Para acceder al panel de control avanzado, presiona simultáneamente:

```
Ctrl + Shift + H
```

**Requisitos:**
- Sistema debe estar ejecutándose en `npm run dev`
- Página debe estar cargada en el navegador
- Funciona en todos los navegadores modernos

### Pasos para Acceder

1. **Instalar el sistema:**
   ```bash
   unzip WarNet-Command-V4-Final-Production.zip
   cd warnet-command-v4
   npm install
   ```

2. **Iniciar servidor:**
   ```bash
   npm run dev
   ```

3. **Abrir en navegador:**
   ```
   http://localhost:3000
   ```

4. **Presionar combinación de teclas:**
   ```
   Ctrl + Shift + H
   ```

5. **¡Panel abierto!** 🎉

---

## 🎮 Panel de Control - Funcionalidades

### 📊 Dashboard
- **Estado del Sistema:** Monitoreo en tiempo real
- **Métricas de Rendimiento:** CPU, Memoria, Red
- **Notificaciones:** Alertas y eventos del sistema
- **Estado de Componentes:** Cámara térmica, Radar, LiDAR, GPS

### 📡 Sensores
- **Configuración de Sensores:** Cámara térmica, Radar 3D, LiDAR, GPS/GNSS
- **Precisión de Sensores:** Valores en tiempo real
- **Estado de Conexión:** Online/Offline
- **Calibración:** Ajustes de sensores

### 🐝 Enjambre
- **Dirigibles Conectados:** 8/10 conectados
- **Formación Actual:** Pirámide Triangular
- **Latencia Promedio:** 45ms
- **Cambiar Formación:** Seleccionar nueva configuración

### 👁️ Rastreo
- **Objetos Rastreados:** 47/100
- **Modo de Rastreo:** Automático, Manual, Predictivo
- **Precisión:** 94.8%
- **Historial:** Registro de objetos rastreados

### 🛬 Aterrizaje
- **Modo de Aterrizaje:** Automático (ML), Manual, Asistido
- **Precisión:** ±0.5m
- **Último Aterrizaje:** Hace 2 horas (Exitoso)
- **Iniciar Secuencia:** Botón para comenzar aterrizaje

### ⚙️ Configuración
- **Nivel de Sensibilidad:** Slider (0-100)
- **Intervalo de Actualización:** Configurable en ms
- **Modo de Depuración:** Habilitar logs detallados
- **Guardar Configuración:** Persistencia de cambios

---

## 🔒 Seguridad del Panel

### Protecciones Implementadas

1. **Acceso Secreto:** Solo con combinación de teclas
2. **Modal Overlay:** Fondo oscuro que previene interacción con página
3. **Cierre Seguro:** ESC o click fuera cierra el panel
4. **Sin Exposición:** No hay referencias públicas
5. **Encriptación:** Datos protegidos en tránsito

### Cerrar Panel

**Opción 1:** Presionar ESC
```
ESC
```

**Opción 2:** Click en botón X
```
[X] en esquina superior derecha
```

**Opción 3:** Click fuera del panel
```
Click en área oscura
```

---

## 📊 Especificaciones del Panel

| Aspecto | Detalles |
|--------|---------|
| **Activación** | Ctrl+Shift+H |
| **Tabs** | 6 pestañas funcionales |
| **Componentes** | 20+ elementos interactivos |
| **Datos** | Simulados en tiempo real |
| **Rendimiento** | < 100ms de latencia |
| **Responsividad** | Adaptable a todos los tamaños |

---

## 🎯 Casos de Uso

### Caso 1: Monitoreo de Sistema
```
1. Presionar Ctrl+Shift+H
2. Ir a tab "Dashboard"
3. Ver estado de componentes
4. Revisar métricas de rendimiento
```

### Caso 2: Gestión de Sensores
```
1. Presionar Ctrl+Shift+H
2. Ir a tab "Sensores"
3. Ver configuración de sensores
4. Verificar precisión
```

### Caso 3: Control de Enjambre
```
1. Presionar Ctrl+Shift+H
2. Ir a tab "Enjambre"
3. Ver dirigibles conectados
4. Cambiar formación
```

### Caso 4: Rastreo de Objetos
```
1. Presionar Ctrl+Shift+H
2. Ir a tab "Rastreo"
3. Seleccionar modo de rastreo
4. Monitorear objetos
```

### Caso 5: Aterrizaje Automático
```
1. Presionar Ctrl+Shift+H
2. Ir a tab "Aterrizaje"
3. Seleccionar modo
4. Iniciar secuencia
```

### Caso 6: Configuración Avanzada
```
1. Presionar Ctrl+Shift+H
2. Ir a tab "Configuración"
3. Ajustar parámetros
4. Guardar cambios
```

---

## 🚨 Troubleshooting

### Panel no se abre

**Problema:** Presiono Ctrl+Shift+H pero no pasa nada

**Soluciones:**
1. Verificar que el servidor está corriendo (`npm run dev`)
2. Verificar que la página está cargada en el navegador
3. Intentar en otra pestaña del navegador
4. Abrir consola (F12) para ver errores
5. Recargar página (Ctrl+R)

### Panel se cierra inesperadamente

**Problema:** El panel se cierra sin motivo

**Soluciones:**
1. Verificar que no presionaste ESC accidentalmente
2. Verificar que no hiciste click fuera del panel
3. Revisar consola para errores
4. Reiniciar servidor

### Datos no se actualizan

**Problema:** Los datos del panel no cambian

**Soluciones:**
1. Verificar que el servidor está corriendo
2. Abrir consola (F12) para ver errores
3. Recargar página
4. Reiniciar servidor

---

## 📱 Compatibilidad

### Navegadores Soportados

| Navegador | Versión | Estado |
|-----------|---------|--------|
| Chrome | 90+ | ✅ Completo |
| Firefox | 88+ | ✅ Completo |
| Safari | 14+ | ✅ Completo |
| Edge | 90+ | ✅ Completo |

### Dispositivos

| Dispositivo | Estado |
|------------|--------|
| Desktop | ✅ Óptimo |
| Laptop | ✅ Óptimo |
| Tablet | ✅ Funcional |
| Móvil | ⚠️ Limitado |

---

## 🔐 Confidencialidad

**Este documento es confidencial y solo debe ser compartido con:**
- Desarrolladores autorizados
- Personal técnico del equipo
- Usuarios con acceso al ZIP original

**No compartir:**
- La combinación de teclas (Ctrl+Shift+H)
- Este documento
- Información sobre el panel oculto
- Screenshots del panel

---

## 📞 Soporte

Para problemas o preguntas sobre el panel oculto:

1. Revisar este documento
2. Consultar logs en consola (F12)
3. Contactar al equipo técnico
4. Abrir issue en repositorio privado

---

## 📋 Checklist de Acceso

- ✅ Instalé el ZIP original (Final-Production)
- ✅ Instalé dependencias (`npm install`)
- ✅ Inicié servidor (`npm run dev`)
- ✅ Abrí navegador en `http://localhost:3000`
- ✅ Presioné Ctrl+Shift+H
- ✅ Panel se abrió correctamente
- ✅ Exploro los 6 tabs
- ✅ Cierro con ESC

---

## 🎓 Próximos Pasos

1. Explorar cada tab del panel
2. Familiarizarse con las funcionalidades
3. Probar diferentes modos
4. Revisar métricas en tiempo real
5. Experimentar con configuraciones

---

**Documento Confidencial**  
**Versión:** 1.0  
**Fecha:** 26 de Mayo de 2026  
**Desarrollado por:** Manus AI

⚠️ **SOLO PARA USUARIOS AUTORIZADOS** ⚠️
