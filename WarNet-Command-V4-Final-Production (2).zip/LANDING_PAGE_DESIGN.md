# WarNet Command V4 - Diseño de Landing Page

**Versión:** 1.0  
**Fecha:** 26 de Mayo de 2026  
**Objetivo:** Landing Page profesional que oculte funcionalidades avanzadas

---

## 1. Concepto General

La Landing Page de WarNet Command V4 presenta el sistema como una **plataforma profesional de control y monitoreo de dirigibles autónomos**. El diseño enfatiza seguridad, precisión y tecnología de punta, mientras mantiene ocultas las funcionalidades avanzadas detrás de un acceso secreto (Ctrl+Shift+H).

### 1.1 Filosofía de Diseño

**Movimiento de Diseño:** Futurismo Corporativo Minimalista  
**Público Objetivo:** Operadores profesionales, ingenieros, tomadores de decisiones  
**Tono:** Profesional, confiable, innovador  
**Paleta de Colores:** Azul profundo (#1a3a52), Cian (#00d4ff), Gris oscuro (#1f2937), Blanco (#ffffff)

---

## 2. Estructura de Navegación

### 2.1 Página Principal (Landing)

**Secciones:**

1. **Hero Section** (Viewport completo)
   - Título: "WarNet Command V4"
   - Subtítulo: "Control Inteligente de Dirigibles Autónomos"
   - Imagen de fondo: Dirigible en cielo nocturno con datos superpuestos
   - CTA Principal: "Acceder al Sistema"
   - CTA Secundaria: "Ver Documentación"

2. **Características Principales** (3 columnas)
   - Sensor Fusion Avanzado
   - Predicción de Aterrizaje ML
   - Coordinación de Enjambre

3. **Especificaciones Técnicas** (Tabla comparativa)
   - Precisión de sensores
   - Latencia de comunicación
   - Capacidad de procesamiento

4. **Seguridad y Confiabilidad**
   - Encriptación de datos
   - Redundancia de sistemas
   - Certificaciones

5. **Equipo y Contacto**
   - Información de contacto
   - Links a redes sociales
   - Formulario de consultas

### 2.2 Rutas Públicas

```
/                    → Landing Page
/features            → Características detalladas
/specifications      → Especificaciones técnicas
/security            → Seguridad y cumplimiento
/contact             → Formulario de contacto
/docs                → Documentación pública
```

### 2.3 Acceso Secreto

**Combinación de Teclas:** Ctrl+Shift+H  
**Acción:** Desbloquea panel de control avanzado  
**Ubicación:** Overlay modal con transición suave  
**Cierre:** ESC o click fuera del modal

---

## 3. Componentes Visuales

### 3.1 Header/Navbar

```
┌─────────────────────────────────────────────────────────────┐
│ [Logo] WarNet V4    [Features] [Specs] [Security] [Contact] │
│                                                   [Login] ▼  │
└─────────────────────────────────────────────────────────────┘
```

**Características:**
- Logo animado con efecto de pulso
- Navbar sticky en scroll
- Menú responsive en móvil
- Indicador visual de sección actual

### 3.2 Hero Section

```
┌──────────────────────────────────────────────────────────────┐
│                                                              │
│   WarNet Command V4                                          │
│   Control Inteligente de Dirigibles Autónomos               │
│                                                              │
│   [Acceder al Sistema]  [Ver Documentación]                 │
│                                                              │
│   [Imagen de fondo: Dirigible con datos superpuestos]       │
│                                                              │
└──────────────────────────────────────────────────────────────┘
```

### 3.3 Características (3 Columnas)

```
┌─────────────┬─────────────┬─────────────┐
│   Sensor    │  Predicción │ Coordinación│
│   Fusion    │  de Aterr.  │  Enjambre   │
│             │             │             │
│ Descripción │ Descripción │ Descripción │
└─────────────┴─────────────┴─────────────┘
```

### 3.4 Especificaciones (Tabla)

```
┌──────────────────┬──────────┬──────────┐
│ Especificación   │  Valor   │ Unidad   │
├──────────────────┼──────────┼──────────┤
│ Precisión Sensor │  99.5%   │ %        │
│ Latencia Comun.  │  50ms    │ ms       │
│ Objetos Rastr.   │  100+    │ objetos  │
└──────────────────┴──────────┴──────────┘
```

---

## 4. Paleta de Colores

| Nombre | Hex | RGB | Uso |
|--------|-----|-----|-----|
| Azul Profundo | #1a3a52 | 26, 58, 82 | Fondo, headers |
| Cian | #00d4ff | 0, 212, 255 | Acentos, botones |
| Gris Oscuro | #1f2937 | 31, 41, 55 | Texto secundario |
| Blanco | #ffffff | 255, 255, 255 | Texto principal |
| Verde Éxito | #10b981 | 16, 185, 129 | Estados positivos |
| Rojo Alerta | #ef4444 | 239, 68, 68 | Estados críticos |

---

## 5. Tipografía

**Font Principal:** Inter (Google Fonts)  
**Font Secundaria:** Space Mono (Monoespaciada)

| Elemento | Font | Tamaño | Peso | Línea |
|----------|------|--------|------|-------|
| H1 | Inter | 48px | 700 | 1.2 |
| H2 | Inter | 36px | 600 | 1.3 |
| H3 | Inter | 24px | 600 | 1.4 |
| Body | Inter | 16px | 400 | 1.6 |
| Small | Inter | 14px | 400 | 1.5 |
| Code | Space Mono | 12px | 400 | 1.4 |

---

## 6. Animaciones y Transiciones

### 6.1 Transiciones Globales

- **Duración estándar:** 300ms
- **Easing:** cubic-bezier(0.4, 0, 0.2, 1)
- **Hover effects:** Cambio de color + elevación

### 6.2 Animaciones Específicas

**Logo Pulse:**
```css
@keyframes pulse {
  0%, 100% { opacity: 1; }
  50% { opacity: 0.7; }
}
animation: pulse 2s infinite;
```

**Fade In on Scroll:**
```css
@keyframes fadeInUp {
  from { opacity: 0; transform: translateY(20px); }
  to { opacity: 1; transform: translateY(0); }
}
animation: fadeInUp 600ms ease-out;
```

**Glow Effect (Botones):**
```css
@keyframes glow {
  0%, 100% { box-shadow: 0 0 5px rgba(0, 212, 255, 0.5); }
  50% { box-shadow: 0 0 20px rgba(0, 212, 255, 0.8); }
}
```

---

## 7. Comportamiento Responsivo

### 7.1 Breakpoints

| Dispositivo | Ancho | Cambios |
|------------|-------|---------|
| Móvil | < 640px | Stack vertical, menú colapsible |
| Tablet | 640-1024px | 2 columnas, nav horizontal |
| Desktop | > 1024px | 3 columnas, nav completo |

### 7.2 Ajustes por Dispositivo

**Móvil:**
- Hero: Imagen de fondo reducida
- Características: Stack vertical
- Tabla: Scroll horizontal
- Botones: Tamaño aumentado (48px)

**Tablet:**
- Hero: Imagen a 70% del viewport
- Características: 2 columnas
- Tabla: Visible completa

**Desktop:**
- Hero: Imagen a 100% del viewport
- Características: 3 columnas
- Tabla: Visible con scroll

---

## 8. Acceso Secreto (Ctrl+Shift+H)

### 8.1 Implementación

**Listener Global:**
```typescript
document.addEventListener('keydown', (e) => {
  if (e.ctrlKey && e.shiftKey && e.key === 'H') {
    showHiddenControlPanel();
  }
});
```

### 8.2 Panel Oculto

**Características:**
- Modal overlay con fondo oscuro
- Animación de entrada: Scale + Fade
- Contenedor del panel de control completo
- Botón de cierre (X) en esquina superior derecha
- Cierre al presionar ESC

**Estructura:**
```
┌────────────────────────────────────────┐
│ WarNet Command Center        [X]       │
├────────────────────────────────────────┤
│                                        │
│  [Panel de Control Completo]           │
│  - Dashboard                           │
│  - Sensores                            │
│  - Enjambre                            │
│  - Rastreo                             │
│  - Configuración                       │
│                                        │
└────────────────────────────────────────┘
```

---

## 9. Elementos Interactivos

### 9.1 Botones

**Estilos:**
- **Primario:** Cian (#00d4ff) con hover glow
- **Secundario:** Borde cian, fondo transparente
- **Terciario:** Texto cian, sin borde

**Estados:**
- Normal: Color base
- Hover: Glow + elevación
- Active: Color más oscuro
- Disabled: Opacidad 50%

### 9.2 Formularios

**Campos:**
- Input: Borde inferior cian, fondo transparente
- Focus: Borde cian + glow
- Error: Borde rojo + icono de alerta
- Success: Borde verde + icono de check

### 9.3 Cards

**Estructura:**
- Fondo: Gris oscuro (#1f2937)
- Borde: Cian 1px
- Sombra: Suave (0 4px 6px rgba(0, 0, 0, 0.1))
- Hover: Elevación + borde más brillante

---

## 10. Secciones Detalladas

### 10.1 Hero Section

**Contenido:**
- Título principal con animación de fade-in
- Subtítulo descriptivo
- Dos botones de CTA
- Imagen de fondo con overlay oscuro
- Scroll indicator animado

**Altura:** 100vh  
**Alineación:** Centro vertical y horizontal

### 10.2 Características

**Layout:** 3 columnas en desktop, 1 en móvil  
**Contenido por columna:**
- Icono (64x64px)
- Título (H3)
- Descripción (Body)
- Link "Más información"

### 10.3 Especificaciones

**Tabla con:**
- 3 columnas: Especificación, Valor, Unidad
- Filas alternadas con fondo ligeramente diferente
- Hover effect en filas
- Responsive: Scroll horizontal en móvil

### 10.4 Seguridad

**Puntos clave:**
- Encriptación end-to-end
- Certificación ISO 27001
- Auditorías de seguridad regulares
- Cumplimiento GDPR

**Visual:** Iconos + texto + badges

### 10.5 Footer

**Contenido:**
- Logo + copyright
- Links rápidos
- Redes sociales
- Formulario de newsletter
- Información de contacto

---

## 11. Flujo de Usuario

### 11.1 Usuario Público

```
Llega a Landing → Lee características → Consulta specs → 
Contacta → Recibe información
```

### 11.2 Usuario Autorizado (Ctrl+Shift+H)

```
Llega a Landing → Presiona Ctrl+Shift+H → Panel oculto → 
Accede a control completo → Gestiona sistema
```

---

## 12. Requisitos Técnicos

### 12.1 Rendimiento

- **Lighthouse Score:** 90+ en todas las categorías
- **First Contentful Paint:** < 1.5s
- **Largest Contentful Paint:** < 2.5s
- **Cumulative Layout Shift:** < 0.1

### 12.2 Compatibilidad

- Chrome 90+
- Firefox 88+
- Safari 14+
- Edge 90+
- Mobile browsers (iOS Safari 14+, Chrome Android)

### 12.3 Accesibilidad

- WCAG 2.1 AA compliance
- Contraste de colores: 4.5:1 mínimo
- Navegación por teclado completa
- Alt text en todas las imágenes
- Aria labels donde sea necesario

---

## 13. Conclusión

La Landing Page de WarNet Command V4 presenta un sistema profesional y confiable, mientras mantiene las funcionalidades avanzadas ocultas detrás de un acceso secreto. El diseño es moderno, responsivo y accesible, optimizado para convertir visitantes en usuarios.

**Próximos pasos:**
1. Implementar componentes React
2. Integrar animaciones
3. Agregar lógica del panel oculto
4. Testing en múltiples navegadores
5. Optimización de performance

---

**Diseño por:** Manus AI  
**Fecha:** 26 de Mayo de 2026  
**Versión:** 1.0
