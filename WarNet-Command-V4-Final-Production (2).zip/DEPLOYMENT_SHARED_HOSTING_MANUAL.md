# WarNet Command Center V4 - Manual de Despliegue en Hosting Compartido

## 📋 Tabla de Contenidos

1. [Requisitos Previos](#requisitos-previos)
2. [Preparación del Proyecto](#preparación-del-proyecto)
3. [Compilación para Producción](#compilación-para-producción)
4. [Configuración del Hosting](#configuración-del-hosting)
5. [Subida de Archivos](#subida-de-archivos)
6. [Configuración del Servidor](#configuración-del-servidor)
7. [Pruebas y Validación](#pruebas-y-validación)
8. [Troubleshooting](#troubleshooting)

---

## 🔧 Requisitos Previos

### En tu Computadora Local

- ✅ Node.js 18+ instalado
- ✅ npm o pnpm instalado
- ✅ Git instalado
- ✅ Acceso SSH a tu hosting (recomendado)
- ✅ Cliente FTP (FileZilla, WinSCP, etc.)
- ✅ Editor de texto (VS Code, Sublime, etc.)

### En el Hosting Compartido

- ✅ Soporte para Node.js (o al menos PHP con exec)
- ✅ Espacio en disco: mínimo 500 MB
- ✅ Ancho de banda: mínimo 10 GB/mes
- ✅ Acceso a cPanel, Plesk o panel similar
- ✅ Soporte para .htaccess (Apache)
- ✅ Acceso SSH (opcional pero recomendado)

---

## 📦 Preparación del Proyecto

### Paso 1: Descargar y Preparar

```bash
# Descargar el ZIP
unzip WarNet-Command-V4-Final-Production.zip
cd WarNet-Final-Production

# Limpiar directorios no necesarios
rm -rf node_modules
rm -rf .git
rm -rf .github
rm -rf tests
rm -rf coverage
```

### Paso 2: Crear Archivo .env para Producción

```bash
cat > .env.production << 'EOF'
# Configuración de Producción
VITE_API_URL=https://tu-dominio.com/api
VITE_APP_ENV=production
VITE_DEBUG=false
VITE_LOG_LEVEL=error

# Configuración de Seguridad
VITE_ENABLE_HTTPS=true
VITE_CORS_ENABLED=true

# Configuración de Sensores
VITE_RADAR_ENABLED=true
VITE_THERMAL_ENABLED=true
VITE_LLM_ENABLED=true

# Configuración de Almacenamiento
VITE_STORAGE_TYPE=localstorage
VITE_MAX_STORAGE_SIZE=50MB
EOF
```

### Paso 3: Instalar Dependencias Localmente

```bash
npm install
# O si usas pnpm:
pnpm install
```

---

## 🔨 Compilación para Producción

### Paso 1: Compilar el Proyecto

```bash
# Compilar con optimizaciones
npm run build

# Verificar que se creó la carpeta dist/
ls -la dist/
```

### Paso 2: Verificar Tamaño

```bash
# El tamaño total debe ser menor a 50 MB
du -sh dist/

# Listar archivos más grandes
du -sh dist/* | sort -rh | head -10
```

### Paso 3: Crear Archivo de Configuración para Hosting

```bash
# Crear archivo .htaccess para Apache
cat > dist/.htaccess << 'EOF'
# Habilitar mod_rewrite
<IfModule mod_rewrite.c>
  RewriteEngine On
  RewriteBase /
  
  # Redirigir todas las solicitudes a index.html
  RewriteCond %{REQUEST_FILENAME} !-f
  RewriteCond %{REQUEST_FILENAME} !-d
  RewriteRule ^ index.html [QSA,L]
  
  # Habilitar compresión
  <IfModule mod_deflate.c>
    AddOutputFilterByType DEFLATE text/html text/plain text/xml text/css text/javascript application/javascript
  </IfModule>
  
  # Cache headers
  <IfModule mod_expires.c>
    ExpiresActive On
    ExpiresByType text/html "access plus 1 hour"
    ExpiresByType text/css "access plus 1 month"
    ExpiresByType application/javascript "access plus 1 month"
    ExpiresByType image/jpeg "access plus 1 month"
    ExpiresByType image/png "access plus 1 month"
    ExpiresByType image/gif "access plus 1 month"
    ExpiresByType image/svg+xml "access plus 1 month"
  </IfModule>
  
  # Headers de seguridad
  Header set X-Content-Type-Options "nosniff"
  Header set X-Frame-Options "SAMEORIGIN"
  Header set X-XSS-Protection "1; mode=block"
  Header set Referrer-Policy "strict-origin-when-cross-origin"
</IfModule>
EOF
```

### Paso 4: Crear Archivo de Configuración para Nginx (si aplica)

```bash
# Crear archivo nginx.conf
cat > nginx.conf << 'EOF'
server {
    listen 80;
    server_name tu-dominio.com www.tu-dominio.com;
    
    root /home/usuario/public_html/warnet;
    index index.html;
    
    # Compresión
    gzip on;
    gzip_types text/plain text/css text/xml text/javascript 
               application/x-javascript application/xml+rss 
               application/javascript;
    
    # Cache
    location ~* \.(js|css|png|jpg|jpeg|gif|ico|svg|woff|woff2|ttf|eot)$ {
        expires 1y;
        add_header Cache-Control "public, immutable";
    }
    
    # Redirigir a index.html para rutas SPA
    location / {
        try_files $uri $uri/ /index.html;
    }
    
    # Headers de seguridad
    add_header X-Content-Type-Options "nosniff";
    add_header X-Frame-Options "SAMEORIGIN";
    add_header X-XSS-Protection "1; mode=block";
    add_header Referrer-Policy "strict-origin-when-cross-origin";
}
EOF
```

---

## 🌐 Configuración del Hosting

### Opción A: Usando cPanel (Más Común)

#### Paso 1: Acceder a cPanel

1. Abre tu navegador
2. Ve a `https://tu-dominio.com:2083` o `https://ip-servidor:2083`
3. Ingresa tus credenciales de cPanel
4. Busca "File Manager" o "Gestor de Archivos"

#### Paso 2: Crear Carpeta para la Aplicación

1. Abre File Manager
2. Navega a `public_html`
3. Crea una carpeta llamada `warnet` (o el nombre que prefieras)
4. Dentro crea una subcarpeta llamada `dist`

#### Paso 3: Subir Archivos

**Opción 1: Usando FTP**

```bash
# Conectar por FTP desde tu computadora
ftp tu-dominio.com

# Comandos FTP
put .htaccess /public_html/warnet/
put -r dist/* /public_html/warnet/dist/

# O usando lftp (más rápido)
lftp -u usuario,contraseña tu-dominio.com
mirror -R dist/ /public_html/warnet/dist/
```

**Opción 2: Usando SSH (Recomendado)**

```bash
# Conectar por SSH
ssh usuario@tu-dominio.com

# Navegar a la carpeta
cd public_html
mkdir -p warnet/dist

# Copiar archivos (desde tu computadora)
scp -r dist/* usuario@tu-dominio.com:~/public_html/warnet/dist/
scp .htaccess usuario@tu-dominio.com:~/public_html/warnet/
```

#### Paso 4: Configurar Dominio Apuntado

1. En cPanel, busca "Addon Domains" o "Dominios Adicionales"
2. Agrega tu dominio apuntando a la carpeta `public_html/warnet`
3. Espera 24 horas para que se propague el DNS

### Opción B: Usando Plesk

#### Paso 1: Acceder a Plesk

1. Abre tu navegador
2. Ve a `https://tu-dominio.com:8443` o `https://ip-servidor:8443`
3. Ingresa tus credenciales

#### Paso 2: Crear Sitio Web

1. Ve a "Sitios Web"
2. Haz clic en "Agregar Sitio Web"
3. Ingresa tu dominio
4. Selecciona la carpeta raíz como `httpdocs/warnet`

#### Paso 3: Subir Archivos

1. Ve a "Archivos"
2. Navega a `httpdocs/warnet`
3. Sube los archivos del directorio `dist/`

---

## 📤 Subida de Archivos

### Método 1: FTP (Más Lento pero Seguro)

```bash
# Instalar cliente FTP si no lo tienes
# Windows: Descargar FileZilla desde filezilla-project.org
# Mac/Linux: sudo apt-get install lftp

# Conectar
lftp -u usuario,contraseña tu-dominio.com

# Comandos
cd public_html/warnet
mirror -R dist/ dist/
put .htaccess

# Salir
quit
```

### Método 2: SSH (Más Rápido)

```bash
# Desde tu computadora, en la carpeta del proyecto
cd dist

# Comprimir para transferencia más rápida
tar -czf warnet-dist.tar.gz .

# Transferir
scp warnet-dist.tar.gz usuario@tu-dominio.com:~/public_html/warnet/

# Conectar por SSH y descomprimir
ssh usuario@tu-dominio.com
cd ~/public_html/warnet
tar -xzf warnet-dist.tar.gz
rm warnet-dist.tar.gz

# Establecer permisos correctos
chmod -R 755 .
chmod -R 644 *.html *.css *.js
```

### Método 3: Usando Panel Web (Más Fácil)

1. Abre el File Manager en cPanel/Plesk
2. Navega a `public_html/warnet`
3. Haz clic en "Upload"
4. Selecciona todos los archivos de `dist/`
5. Espera a que se suban

---

## ⚙️ Configuración del Servidor

### Paso 1: Verificar Permisos

```bash
# Conectar por SSH
ssh usuario@tu-dominio.com

# Navegar a la carpeta
cd public_html/warnet

# Establecer permisos correctos
chmod 755 .
chmod -R 755 *
chmod 644 *.html *.css *.js *.json
chmod 644 .htaccess
```

### Paso 2: Habilitar Compresión GZIP

**En cPanel:**
1. Ve a "EasyApache" o "MultiPHP Manager"
2. Asegúrate de que mod_deflate esté habilitado
3. Reinicia Apache

**En Plesk:**
1. Ve a "Configuración de Servidor"
2. Habilita "Compresión GZIP"

### Paso 3: Configurar HTTPS/SSL

**En cPanel:**
1. Ve a "AutoSSL" o "SSL/TLS"
2. Instala un certificado Let's Encrypt (gratis)
3. Espera a que se instale (5-10 minutos)

**En Plesk:**
1. Ve a "Certificados SSL/TLS"
2. Haz clic en "Obtener certificado Let's Encrypt"
3. Sigue los pasos

### Paso 4: Redirigir HTTP a HTTPS

```bash
# Editar .htaccess
ssh usuario@tu-dominio.com
cd public_html/warnet
nano .htaccess

# Agregar estas líneas al principio:
RewriteEngine On
RewriteCond %{HTTPS} off
RewriteRule ^(.*)$ https://%{HTTP_HOST}%{REQUEST_URI} [L,R=301]
```

---

## ✅ Pruebas y Validación

### Paso 1: Verificar Acceso

```bash
# Abre tu navegador
https://tu-dominio.com

# Deberías ver la interfaz de WarNet Command Center
```

### Paso 2: Verificar Consola del Navegador

1. Abre DevTools (F12)
2. Ve a la pestaña "Console"
3. No debe haber errores rojos
4. Verifica que no haya errores de CORS

### Paso 3: Pruebas de Funcionalidad

- [ ] Cargar página principal
- [ ] Navegar entre pestañas
- [ ] Abrir panel oculto (Ctrl+Shift+H)
- [ ] Probar Google 3D Navigation
- [ ] Probar Voice Assistant
- [ ] Probar Dashboard Analytics
- [ ] Probar LLM Object Tracker
- [ ] Probar Directed Tracking

### Paso 4: Pruebas de Rendimiento

```bash
# Usar herramienta online
# https://www.webpagetest.org/
# https://pagespeed.web.dev/

# O desde terminal
curl -I https://tu-dominio.com

# Verificar headers
# Debe mostrar:
# - Content-Encoding: gzip
# - Cache-Control: public
# - X-Content-Type-Options: nosniff
```

### Paso 5: Verificar Seguridad

```bash
# Usar SSL Labs
# https://www.ssllabs.com/ssltest/

# Usar Mozilla Observatory
# https://observatory.mozilla.org/

# Ambos deben mostrar A o A+
```

---

## 🐛 Troubleshooting

### Problema 1: Error 404 en Rutas

**Síntoma:** Al navegar a `/map` o `/fleet`, obtienes 404

**Solución:**
```bash
# Verificar que .htaccess está en la carpeta correcta
ssh usuario@tu-dominio.com
ls -la public_html/warnet/.htaccess

# Si no existe, crear:
cat > public_html/warnet/.htaccess << 'EOF'
<IfModule mod_rewrite.c>
  RewriteEngine On
  RewriteBase /
  RewriteCond %{REQUEST_FILENAME} !-f
  RewriteCond %{REQUEST_FILENAME} !-d
  RewriteRule ^ index.html [QSA,L]
</IfModule>
EOF
```

### Problema 2: Archivos CSS/JS no Cargan

**Síntoma:** Página se ve sin estilos

**Solución:**
```bash
# Verificar permisos
chmod 644 *.css *.js

# Verificar rutas en index.html
# Deben ser relativas: /assets/... NO /warnet/assets/...
```

### Problema 3: CORS Error

**Síntoma:** Error en consola: "CORS policy"

**Solución:**
```bash
# Agregar headers CORS al .htaccess
cat >> public_html/warnet/.htaccess << 'EOF'
<IfModule mod_headers.c>
  Header set Access-Control-Allow-Origin "*"
  Header set Access-Control-Allow-Methods "GET, POST, PUT, DELETE, OPTIONS"
  Header set Access-Control-Allow-Headers "Content-Type, Authorization"
</IfModule>
EOF
```

### Problema 4: Página Lenta

**Síntoma:** Carga tarda más de 3 segundos

**Solución:**
```bash
# Habilitar caché
# Verificar que .htaccess tiene:
<IfModule mod_expires.c>
  ExpiresActive On
  ExpiresByType text/css "access plus 1 month"
  ExpiresByType application/javascript "access plus 1 month"
</IfModule>

# Habilitar compresión GZIP
# Verificar que mod_deflate está habilitado en cPanel
```

### Problema 5: Almacenamiento Agotado

**Síntoma:** Error: "Disk space exceeded"

**Solución:**
```bash
# Comprimir archivos no necesarios
cd public_html/warnet
tar -czf backup.tar.gz dist/
rm -rf dist/
tar -xzf backup.tar.gz
rm backup.tar.gz

# O eliminar caché
rm -rf .cache/
```

---

## 📊 Monitoreo y Mantenimiento

### Verificar Logs

```bash
# En cPanel
# Ve a "Error Log" o "Raw Access Log"

# O por SSH
ssh usuario@tu-dominio.com
tail -f /home/usuario/public_html/warnet/error.log
```

### Actualizar Aplicación

```bash
# Compilar nueva versión localmente
npm run build

# Comprimir
tar -czf warnet-update.tar.gz dist/

# Transferir
scp warnet-update.tar.gz usuario@tu-dominio.com:~/public_html/warnet/

# Descomprimir
ssh usuario@tu-dominio.com
cd ~/public_html/warnet
tar -xzf warnet-update.tar.gz
rm warnet-update.tar.gz
```

### Backup Regular

```bash
# Crear backup
ssh usuario@tu-dominio.com
cd public_html
tar -czf warnet-backup-$(date +%Y%m%d).tar.gz warnet/

# Descargar backup
scp usuario@tu-dominio.com:~/public_html/warnet-backup-*.tar.gz ./
```

---

## 🎯 Checklist Final

- [ ] Proyecto compilado localmente
- [ ] Archivos subidos al hosting
- [ ] .htaccess configurado correctamente
- [ ] HTTPS/SSL instalado
- [ ] Permisos establecidos (755/644)
- [ ] Página carga sin errores
- [ ] Todas las pestañas funcionan
- [ ] Panel oculto accesible (Ctrl+Shift+H)
- [ ] Compresión GZIP habilitada
- [ ] Cache configurado
- [ ] Seguridad verificada (SSL Labs A+)
- [ ] Rendimiento optimizado (< 3s carga)

---

## 📞 Soporte del Hosting

Si encuentras problemas específicos del hosting:

1. Contacta al soporte técnico de tu proveedor
2. Proporciona esta información:
   - Tipo de hosting (cPanel, Plesk, etc.)
   - Versión de PHP (si aplica)
   - Versión de Apache/Nginx
   - Errores específicos del log

---

## 📚 Recursos Útiles

- **Apache .htaccess:** https://httpd.apache.org/docs/current/howto/htaccess.html
- **Nginx Configuration:** https://nginx.org/en/docs/
- **Let's Encrypt:** https://letsencrypt.org/
- **SSL Labs:** https://www.ssllabs.com/ssltest/
- **PageSpeed Insights:** https://pagespeed.web.dev/

---

**Versión:** 1.0  
**Última actualización:** Mayo 2026  
**Estado:** Production Ready

---

**¡Tu WarNet Command Center V4 está listo para usar en línea!** 🚀
